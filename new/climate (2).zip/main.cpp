#include<iostream>
#include "climate.h"
#include<fstream>

using namespace std;

int main()
{
	
	climate object(144,12);
	
	
	return 0;
	
}